import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import genericize_and_build as harness


class IdentifierLeakTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rules = harness.load_identifier_rules()

    def test_detects_every_configured_host(self):
        host_rules = [rule for rule in self.rules if rule.kind == "host"]
        self.assertTrue(host_rules)
        for rule in host_rules:
            with self.subTest(rule=rule.name):
                leaks = harness.find_identifier_leaks(
                    f"prefix {rule.value} suffix", self.rules
                )
                self.assertIn(rule.name, leaks)

    def test_detects_every_configured_non_host_identifier(self):
        non_host_rules = [rule for rule in self.rules if rule.kind != "host"]
        self.assertTrue(non_host_rules)
        for rule in non_host_rules:
            with self.subTest(rule=rule.name):
                leaks = harness.find_identifier_leaks(
                    f"prefix {rule.value} suffix", self.rules
                )
                self.assertIn(rule.name, leaks)

    def test_detects_bare_org_host_labels(self):
        host_rules = [rule for rule in self.rules if rule.kind == "host"]
        self.assertTrue(host_rules)
        for rule in host_rules:
            with self.subTest(rule=rule.name):
                label = rule.value.split(".", maxsplit=1)[0]
                leaks = harness.find_identifier_leaks(
                    f"prefix {label} suffix", self.rules
                )
                self.assertIn(rule.name, leaks)

    def test_safe_near_misses_do_not_match(self):
        for rule in self.rules:
            with self.subTest(rule=rule.name):
                boundary_character = "a" if rule.kind == "guid" else "x"
                near_misses = [
                    f"{boundary_character}{rule.value}",
                    f"{rule.value}{boundary_character}",
                ]
                if rule.kind == "host":
                    label = rule.value.split(".", maxsplit=1)[0]
                    near_misses.extend((f"x{label}", f"{label}x"))
                for text in near_misses:
                    self.assertEqual(
                        [],
                        harness.find_identifier_leaks(text, [rule]),
                    )

    def test_unsafe_zip_names_fail(self):
        self.assertFalse(harness.safe_member_name("../solution.xml"))
        self.assertFalse(harness.safe_member_name("C" + ":/solution.xml"))
        self.assertFalse(harness.safe_member_name("/solution.xml"))
        self.assertTrue(harness.safe_member_name("WebResources/a.html"))

    def test_content_manifest_is_order_stable(self):
        entries = [
            {"path": "b", "bytes": 2, "sha256": "bb"},
            {"path": "a", "bytes": 1, "sha256": "aa"},
        ]
        sorted_entries = sorted(entries, key=lambda item: item["path"])
        self.assertEqual(
            harness.content_manifest_sha256(sorted_entries),
            harness.content_manifest_sha256(list(sorted_entries)),
        )

    def test_scans_code_files_for_sensitive_assignments(self):
        findings = harness.find_sensitive_findings(
            "client_" + "sec" + "ret" + ' = "not-a-real-secret"'
        )
        self.assertIn("credential-or-token-assignment", findings)

    def test_variable_token_reference_is_not_a_credential(self):
        self.assertEqual(
            [],
            harness.find_sensitive_findings(
                '$headers = @{ Authorization = "Bearer $token" }'
            ),
        )


class DependencyTests(unittest.TestCase):
    def test_dependency_classification(self):
        self.assertEqual(
            "erac-360-form-pollution",
            harness.classify_missing_dependency(
                {"type": "60", "display_name": "ERAC 360"}
            ),
        )
        self.assertEqual(
            "app-module-or-sitemap-pollution",
            harness.classify_missing_dependency(
                {"type": "80", "display_name": "ERAC Lite CRM"}
            ),
        )
        self.assertEqual(
            "app-setting-platform-prerequisite",
            harness.classify_missing_dependency(
                {"type": "AppSetting", "display_name": "AppChannel"}
            ),
        )


class AppPolicyTests(unittest.TestCase):
    PORTABLE_GUID = "22222222-2222-4222-8222-222222222222"
    OTHER_GUID = "33333333-3333-4333-8333-333333333333"

    @classmethod
    def setUpClass(cls):
        cls.policy = harness.load_json(harness.DEFAULT_POLICY)

    def _form_correlation_errors(
        self,
        *,
        portable_form_id: str | None = PORTABLE_GUID,
        selected_form_id: str | None = PORTABLE_GUID,
        selected_form_present: bool = True,
    ) -> list[str]:
        policy = json.loads(json.dumps(self.policy))
        policy["expected_app_module"]["entities"] = []
        policy["expected_app_module"]["selected_view_count"] = 0
        policy["expected_app_module"]["selected_view_ids"] = []
        policy["expected_app_module"]["sitemap_count"] = 0
        policy["expected_sitemap"]["entities"] = []
        policy["expected_sitemap"]["web_resources"] = []
        policy["expected_sitemap"]["icons"] = []
        policy["portable_account_form"]["fields"] = []
        policy["portable_account_form"]["web_resources"] = []
        selected_id_attribute = (
            "" if selected_form_id is None else f' id="{selected_form_id}"'
        )
        selected_component = (
            f'<AppModuleComponent type="60"{selected_id_attribute} />'
            if selected_form_present
            else ""
        )
        portable_id_node = (
            ""
            if portable_form_id is None
            else f"<formid>{portable_form_id}</formid>"
        )
        source = f"""
        <ImportExportXml>
          <AppModule>
            <UniqueName>erac_ERACLiteCRM</UniqueName>
            <NavigationType>1</NavigationType>
            <WebResourceId>11111111-1111-4111-8111-111111111111</WebResourceId>
            <AppModuleComponents>{selected_component}</AppModuleComponents>
          </AppModule>
          <systemform>
            {portable_id_node}
            <form><tabs /></form>
            <LocalizedNames>
              <LocalizedName description="ERAC Cedent 360 Portable" />
            </LocalizedNames>
          </systemform>
        </ImportExportXml>
        """
        _, errors = harness._validate_expected_app(ET.fromstring(source), policy)
        return errors

    def test_policy_requires_exact_portable_app_inventory(self):
        app = self.policy["expected_app_module"]
        self.assertEqual(10, len(app["entities"]))
        self.assertEqual(7, app["selected_view_count"])
        self.assertEqual(7, len(app["selected_view_ids"]))
        self.assertEqual(7, len(set(app["selected_view_ids"])))
        self.assertEqual(1, app["selected_form_count"])
        self.assertEqual([], sorted(set(app["entities"]) & set(app["forbidden_entities"])))

    def test_policy_requires_all_erac_resources(self):
        sitemap = self.policy["expected_sitemap"]
        form = self.policy["portable_account_form"]
        self.assertEqual(17, len(sitemap["icons"]))
        self.assertEqual(13, len(set(sitemap["web_resources"] + form["web_resources"])))
        self.assertEqual(31, len(form["fields"]))

    def test_missing_app_fails_closed(self):
        inventory, errors = harness._validate_expected_app(
            ET.fromstring("<ImportExportXml />"), self.policy
        )
        self.assertEqual({}, inventory)
        self.assertTrue(any("expected one app module" in item for item in errors))

    def test_guid_normalization(self):
        self.assertEqual(
            "abcdefab-1234-5678-9abc-def012345678",
            harness._normalized_guid("{ABCDEFAB-1234-5678-9ABC-DEF012345678}"),
        )

    def test_malformed_guid_braces_fail_closed(self):
        for value in (
            f"{{{self.PORTABLE_GUID}",
            f"{self.PORTABLE_GUID}}}",
            f"{{{{{self.PORTABLE_GUID}}}}}",
        ):
            with self.subTest(value=value):
                self.assertFalse(harness._is_valid_guid(value))

    def test_missing_portable_form_id_fails_closed(self):
        errors = self._form_correlation_errors(portable_form_id=None)
        self.assertIn(
            "portable Account form formid GUID is absent",
            errors,
        )
        self.assertTrue(any("does not match" in item for item in errors))

    def test_empty_portable_form_id_fails_closed(self):
        errors = self._form_correlation_errors(portable_form_id="")
        self.assertIn(
            "portable Account form formid GUID is empty",
            errors,
        )
        self.assertTrue(any("does not match" in item for item in errors))

    def test_malformed_portable_form_id_fails_closed(self):
        errors = self._form_correlation_errors(portable_form_id="not-a-guid")
        self.assertIn(
            "portable Account form formid GUID is malformed",
            errors,
        )
        self.assertTrue(any("does not match" in item for item in errors))

    def test_missing_selected_form_id_fails_closed(self):
        errors = self._form_correlation_errors(selected_form_id=None)
        self.assertIn("selected app form id GUID is absent", errors)
        self.assertTrue(any("does not match" in item for item in errors))

    def test_empty_selected_form_id_fails_closed(self):
        errors = self._form_correlation_errors(selected_form_id="")
        self.assertIn("selected app form id GUID is empty", errors)
        self.assertTrue(any("does not match" in item for item in errors))

    def test_malformed_selected_form_id_fails_closed(self):
        errors = self._form_correlation_errors(selected_form_id="not-a-guid")
        self.assertIn("selected app form id GUID is malformed", errors)
        self.assertTrue(any("does not match" in item for item in errors))

    def test_missing_selected_form_component_fails_exact_count(self):
        errors = self._form_correlation_errors(selected_form_present=False)
        self.assertTrue(
            any("expected 1 selected app forms, got 0" in item for item in errors)
        )
        self.assertTrue(any("does not match" in item for item in errors))

    def test_mismatched_form_ids_fail_closed(self):
        errors = self._form_correlation_errors(
            selected_form_id=self.OTHER_GUID
        )
        self.assertFalse(any("GUID is" in item for item in errors))
        self.assertTrue(any("does not match" in item for item in errors))

    def test_exact_form_ids_match(self):
        errors = self._form_correlation_errors()
        self.assertFalse(any("GUID is" in item for item in errors))
        self.assertFalse(any("does not match" in item for item in errors))

    def test_brace_and_case_variants_match_after_normalization(self):
        errors = self._form_correlation_errors(
            portable_form_id=f"{{{self.PORTABLE_GUID.upper()}}}",
            selected_form_id=self.PORTABLE_GUID,
        )
        self.assertFalse(any("GUID is" in item for item in errors))
        self.assertFalse(any("does not match" in item for item in errors))


if __name__ == "__main__":
    unittest.main()
