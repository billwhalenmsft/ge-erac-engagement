#!/usr/bin/env python3
"""Validate and pack GE ERAC Lite CRM solution exports without unsafe XML edits.

Power Platform solution exports are already environment-neutral when they do not
contain source org, environment, solution, maker, or repository identifiers.
This harness therefore audits exported ZIPs and delegates packing to PAC. It
never replaces Dataverse component GUIDs or inserts placeholders into solution
XML/web resources.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Iterable
from xml.etree import ElementTree as ET

HERE = Path(__file__).resolve().parent
DEFAULT_IDENTIFIERS = HERE / "release-identifiers.private.json"
DEFAULT_POLICY = HERE / "release-policy.json"
TEXT_SUFFIXES = {
    ".css",
    ".html",
    ".js",
    ".json",
    ".md",
    ".ps1",
    ".psm1",
    ".py",
    ".txt",
    ".webresource",
    ".xml",
    ".xaml",
    ".yaml",
    ".yml",
}
REQUIRED_ZIP_MEMBERS = {
    "[Content_Types].xml",
    "customizations.xml",
    "solution.xml",
}
OPC_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
GUID_PATTERN = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-"
    r"[0-9a-f]{4}-[0-9a-f]{12}"
)


@dataclass(frozen=True)
class IdentifierRule:
    name: str
    kind: str
    value: str

    def pattern(self) -> re.Pattern[str]:
        if self.kind == "guid":
            escaped = re.escape(self.value)
            boundary = r"[0-9a-f]"
        elif self.kind == "host":
            label = self.value.split(".", maxsplit=1)[0]
            escaped = rf"(?:{re.escape(self.value)}|{re.escape(label)})"
            boundary = r"[a-z0-9.-]"
        else:
            escaped = re.escape(self.value)
            boundary = r"[a-z0-9_]"
        return re.compile(
            rf"(?<!{boundary}){escaped}(?!{boundary})",
            flags=re.IGNORECASE,
        )


def load_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def load_identifier_rules(path: Path = DEFAULT_IDENTIFIERS) -> list[IdentifierRule]:
    data = load_json(path)
    return [
        IdentifierRule(item["name"], item["kind"], item["value"])
        for item in data["identifiers"]
    ]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_member_name(name: str) -> bool:
    if not name or "\\" in name or name.startswith(("/", "\\")):
        return False
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts:
        return False
    return not re.match(r"^[A-Za-z]:", name)


def find_identifier_leaks(
    text: str, rules: Iterable[IdentifierRule]
) -> list[str]:
    return [rule.name for rule in rules if rule.pattern().search(text)]


def find_sensitive_findings(text: str) -> list[str]:
    checks = {
        "credential-or-token-assignment": re.compile(
            r"(?i)(password|passwd|secret|client[_-]?secret|access[_-]?token)"
            r"\s*[:=]\s*['\"][^'\"]+"
        ),
        "absolute-local-path": re.compile(r"(?i)(?<![A-Za-z])[A-Z]:[\\/]"),
        "private-maker-url": re.compile(
            r"(?i)https://make\.powerapps\.com/environments/"
            r"[0-9a-f-]{36}(?:/solutions/[0-9a-f-]{36})?"
        ),
        "source-repository-url": re.compile(
            r"(?i)https?://(?:www\.)?github\.com/[^/\s]+/"
        ),
    }
    return [
        category for category, pattern in checks.items() if pattern.search(text)
    ]


def _xml_from_zip(archive: zipfile.ZipFile, name: str) -> ET.Element:
    try:
        return ET.fromstring(archive.read(name))
    except ET.ParseError as exc:
        raise ValueError(f"{name} is not valid XML: {exc}") from exc


def _manifest_entry(info: zipfile.ZipInfo, content: bytes) -> dict[str, Any]:
    return {
        "path": info.filename,
        "bytes": info.file_size,
        "compressed_bytes": info.compress_size,
        "crc32": f"{info.CRC:08x}",
        "sha256": sha256_bytes(content),
    }


def content_manifest_sha256(entries: list[dict[str, Any]]) -> str:
    canonical = "\n".join(
        f"{entry['path']}\t{entry['bytes']}\t{entry['sha256']}"
        for entry in entries
    )
    return sha256_bytes(canonical.encode("utf-8"))


def _required_summary(required: ET.Element) -> dict[str, Any]:
    return {
        "type": required.get("type", ""),
        "schema_name": required.get("schemaName", ""),
        "display_name": required.get("displayName", ""),
        "solution": required.get("solution", ""),
        "parent_schema_name": required.get("parentSchemaName", ""),
        "packages": [
            {
                "app_name": package.get("appName", ""),
                "version": package.get("version", ""),
                "anchor": (package.text or "").strip(),
            }
            for package in required.findall("package")
        ],
    }


def _dependent_summary(dependent: ET.Element) -> dict[str, str]:
    return {
        "type": dependent.get("type", ""),
        "schema_name": dependent.get("schemaName", ""),
        "display_name": dependent.get("displayName", ""),
        "parent_display_name": dependent.get("parentDisplayName", ""),
        "id": dependent.get("id", ""),
    }


def classify_missing_dependency(dependent: dict[str, str]) -> str:
    if dependent["type"] == "60" and dependent["display_name"] == "ERAC 360":
        return "erac-360-form-pollution"
    if dependent["type"] in {"62", "80"}:
        return "app-module-or-sitemap-pollution"
    if dependent["type"] == "AppSetting":
        return "app-setting-platform-prerequisite"
    return "external-prerequisite"


def _component_inventory(manifest: ET.Element) -> dict[str, Any]:
    root_components = manifest.find("RootComponents")
    components = [] if root_components is None else list(root_components)
    by_type = Counter(item.get("type", "") for item in components)
    return {
        "total": len(components),
        "counts_by_type": dict(sorted(by_type.items())),
        "components": [
            {
                "type": item.get("type", ""),
                "schema_name": item.get("schemaName", ""),
                "behavior": item.get("behavior", ""),
            }
            for item in components
        ],
    }


def _validate_expected_inventory(
    inventory: dict[str, Any], policy: dict[str, Any]
) -> list[str]:
    errors: list[str] = []
    expected = policy["expected_root_components"]
    actual_by_type: dict[str, list[str]] = {}
    for component in inventory["components"]:
        actual_by_type.setdefault(component["type"], []).append(
            component["schema_name"]
        )
    for component_type, expected_names in expected.items():
        actual_names = sorted(actual_by_type.get(component_type, []))
        if actual_names != sorted(expected_names):
            errors.append(
                "root component mismatch for type "
                f"{component_type}: expected {sorted(expected_names)!r}, "
                f"got {actual_names!r}"
            )
    unexpected_types = sorted(set(actual_by_type) - set(expected))
    if unexpected_types:
        errors.append(f"unexpected root component types: {unexpected_types!r}")
    return errors



def _normalized_guid(value: str | None) -> str:
    normalized = (value or "").strip()
    if normalized.startswith("{") and normalized.endswith("}"):
        normalized = normalized[1:-1]
    return normalized.casefold()


def _is_valid_guid(value: str | None) -> bool:
    return bool(GUID_PATTERN.fullmatch(_normalized_guid(value)))


def _validate_guid_value(
    value: str | None,
    label: str,
    errors: list[str],
) -> str:
    normalized = _normalized_guid(value)
    if value is None:
        errors.append(f"{label} is absent")
    elif not value.strip():
        errors.append(f"{label} is empty")
    elif not _is_valid_guid(value):
        errors.append(f"{label} is malformed")
    return normalized


def _localized_name(node: ET.Element) -> str:
    localized = node.find("LocalizedNames/LocalizedName")
    return "" if localized is None else localized.get("description", "")


def _validate_expected_app(
    customizations: ET.Element, policy: dict[str, Any]
) -> tuple[dict[str, Any], list[str]]:
    app_policy = policy.get("expected_app_module")
    sitemap_policy = policy.get("expected_sitemap")
    form_policy = policy.get("portable_account_form")
    if not app_policy or not sitemap_policy or not form_policy:
        return {}, ["release policy is missing app, sitemap, or form allowlists"]

    errors: list[str] = []
    apps = [
        item
        for item in customizations.iter("AppModule")
        if item.findtext("UniqueName", "") == app_policy["unique_name"]
    ]
    if len(apps) != 1:
        return {}, [
            f"expected one app module {app_policy['unique_name']!r}, got {len(apps)}"
        ]
    app = apps[0]
    components = list(app.findall("AppModuleComponents/AppModuleComponent"))
    entities = sorted(
        item.get("schemaName", "")
        for item in components
        if item.get("type") == "1"
    )
    views = sorted(
        _normalized_guid(item.get("id", ""))
        for item in components
        if item.get("type") == "26"
    )
    raw_form_ids = [
        item.get("id")
        for item in components
        if item.get("type") == "60"
    ]
    forms = sorted(_normalized_guid(value) for value in raw_form_ids)
    selected_form_id = ""
    sitemaps = [
        item.get("schemaName", "")
        for item in components
        if item.get("type") == "62"
    ]
    settings = sorted(
        item.get("settingdefinitionid.uniquename", "")
        for item in app.findall("appsettings/appsetting")
    )
    if entities != sorted(app_policy["entities"]):
        errors.append(
            f"app entity allowlist mismatch: expected {sorted(app_policy['entities'])!r}, "
            f"got {entities!r}"
        )
    if len(views) != app_policy["selected_view_count"]:
        errors.append(
            f"expected {app_policy['selected_view_count']} selected app views, "
            f"got {len(views)}"
        )
    expected_view_ids = sorted(
        _normalized_guid(item) for item in app_policy["selected_view_ids"]
    )
    if views != expected_view_ids:
        errors.append(
            f"selected app view allowlist mismatch: expected {expected_view_ids!r}, "
            f"got {views!r}"
        )
    if len(forms) != app_policy["selected_form_count"]:
        errors.append(
            f"expected {app_policy['selected_form_count']} selected app forms, "
            f"got {len(forms)}"
        )
    if len(raw_form_ids) == 1:
        selected_form_id = _validate_guid_value(
            raw_form_ids[0],
            "selected app form id GUID",
            errors,
        )
    if len(sitemaps) != app_policy["sitemap_count"]:
        errors.append(
            f"expected {app_policy['sitemap_count']} app sitemap component, "
            f"got {len(sitemaps)}"
        )
    if app.findtext("NavigationType", "") != app_policy["navigation_type"]:
        errors.append("app navigation type does not match the curated sitemap policy")
    forbidden_entities = sorted(
        set(entities).intersection(app_policy["forbidden_entities"])
    )
    if forbidden_entities:
        errors.append(f"app contains forbidden entities: {forbidden_entities!r}")
    forbidden_settings = sorted(
        set(settings).intersection(app_policy["forbidden_app_settings"])
    )
    if forbidden_settings:
        errors.append(f"app contains forbidden settings: {forbidden_settings!r}")
    app_text = ET.tostring(app, encoding="unicode").casefold()
    app_tokens = sorted(
        token
        for token in app_policy["forbidden_tokens"]
        if token.casefold() in app_text
    )
    if app_tokens:
        errors.append(f"app contains forbidden tokens: {app_tokens!r}")

    resources = {}
    for item in customizations.iter("WebResource"):
        resource_id = _normalized_guid(item.findtext("WebResourceId", ""))
        if resource_id:
            resources[resource_id] = item.findtext("Name", "")
    app_icon_id = _normalized_guid(app.findtext("WebResourceId", ""))
    app_icon_name = resources.get(app_icon_id, "")
    if not app_icon_name.startswith("erac_"):
        errors.append(
            f"app icon is not an ERAC web resource: {app_icon_name or app_icon_id!r}"
        )

    sitemap_nodes = [
        item
        for item in customizations.iter("AppModuleSiteMap")
        if item.findtext("SiteMapUniqueName", "") == sitemap_policy["unique_name"]
    ]
    if len(sitemap_nodes) != 1:
        errors.append(
            f"expected one sitemap {sitemap_policy['unique_name']!r}, "
            f"got {len(sitemap_nodes)}"
        )
        sitemap_entities: list[str] = []
        sitemap_resources: list[str] = []
        sitemap_icons: list[str] = []
    else:
        sitemap = sitemap_nodes[0]
        subareas = list(sitemap.iter("SubArea"))
        sitemap_entities = sorted(
            {item.get("Entity", "") for item in subareas if item.get("Entity")}
        )
        sitemap_resources = sorted(
            {
                item.get("Url", "").split(":", 1)[1]
                for item in subareas
                if item.get("Url", "").startswith("$webresource:")
            }
        )
        sitemap_icons = sorted(
            {
                item.get("Icon", "").removeprefix("/WebResources/")
                for item in subareas
                if item.get("Icon", "").startswith("/WebResources/")
            }
        )
        if sitemap_entities != sorted(sitemap_policy["entities"]):
            errors.append("sitemap entity allowlist mismatch")
        if sitemap_resources != sorted(sitemap_policy["web_resources"]):
            errors.append("sitemap web-resource allowlist mismatch")
        if sitemap_icons != sorted(sitemap_policy["icons"]):
            errors.append("sitemap icon allowlist mismatch")

    portable_forms = [
        item
        for item in customizations.iter("systemform")
        if _localized_name(item) == form_policy["name"]
    ]
    if len(portable_forms) != 1:
        errors.append(
            f"expected one portable Account form {form_policy['name']!r}, "
            f"got {len(portable_forms)}"
        )
        portable_form_id = ""
        form_fields: list[str] = []
        form_resources: list[str] = []
        form_tokens: list[str] = []
    else:
        formid_node = portable_forms[0].find("formid")
        portable_form_id = _validate_guid_value(
            None if formid_node is None else (formid_node.text or ""),
            "portable Account form formid GUID",
            errors,
        )
        form = portable_forms[0].find("form")
        if form is None:
            errors.append("portable Account form is missing form XML")
            form_fields = []
            form_resources = []
            form_tokens = []
        else:
            form_fields = sorted(
                {
                    item.get("datafieldname", "")
                    for item in form.iter("control")
                    if item.get("datafieldname")
                }
            )
            form_resources = sorted(
                {
                    (item.text or "")
                    for item in form.findall(".//control/parameters/Url")
                }
            )
            if form_fields != sorted(form_policy["fields"]):
                errors.append("portable Account form field allowlist mismatch")
            if form_resources != sorted(form_policy["web_resources"]):
                errors.append("portable Account form web-resource allowlist mismatch")
            form_text = ET.tostring(form, encoding="unicode").casefold()
            form_tokens = sorted(
                token
                for token in form_policy["forbidden_tokens"]
                if token.casefold() in form_text
            )
            if form_tokens:
                errors.append(
                    f"portable Account form contains forbidden tokens: {form_tokens!r}"
                )
    if selected_form_id != portable_form_id:
        errors.append(
            "selected app form does not match the named portable Account form"
        )

    return {
        "unique_name": app_policy["unique_name"],
        "entities": entities,
        "selected_view_ids": views,
        "selected_form_ids": forms,
        "sitemaps": sitemaps,
        "app_settings": settings,
        "navigation_type": app.findtext("NavigationType", ""),
        "app_icon_name": app_icon_name,
        "sitemap_entities": sitemap_entities,
        "sitemap_web_resources": sitemap_resources,
        "sitemap_icons": sitemap_icons,
        "portable_form_name": form_policy["name"],
        "portable_form_id": portable_form_id,
        "portable_form_fields": form_fields,
        "portable_form_web_resources": form_resources,
        "forbidden_app_token_findings": app_tokens,
        "forbidden_form_token_findings": form_tokens,
    }, errors

def validate_solution_zip(
    zip_path: Path,
    expected_type: str,
    *,
    identifiers_path: Path = DEFAULT_IDENTIFIERS,
    policy_path: Path = DEFAULT_POLICY,
) -> dict[str, Any]:
    expected_type = expected_type.lower()
    if expected_type not in {"managed", "unmanaged"}:
        raise ValueError("expected_type must be Managed or Unmanaged")

    policy = load_json(policy_path)
    rules = load_identifier_rules(identifiers_path)
    errors: list[str] = []
    warnings: list[str] = []
    leaks: list[dict[str, str]] = []
    sensitive_findings: list[dict[str, str]] = []
    web_resource_findings: list[dict[str, str]] = []

    if not zip_path.is_file():
        raise FileNotFoundError(zip_path)

    with zipfile.ZipFile(zip_path) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        lowered = [name.casefold() for name in names]
        if len(lowered) != len(set(lowered)):
            errors.append("ZIP contains duplicate entry names (case-insensitive)")
        unsafe = sorted(name for name in names if not safe_member_name(name))
        if unsafe:
            errors.append(f"ZIP contains unsafe entry names: {unsafe!r}")
        missing_members = sorted(REQUIRED_ZIP_MEMBERS - set(names))
        if missing_members:
            errors.append(f"ZIP is missing required members: {missing_members!r}")

        entry_manifest = []
        for info in sorted(infos, key=lambda item: item.filename.casefold()):
            content = archive.read(info)
            entry_manifest.append(_manifest_entry(info, content))
            suffix = Path(info.filename).suffix.lower()
            if suffix not in TEXT_SUFFIXES:
                continue
            text = content.decode("utf-8", errors="replace")
            for leak in find_identifier_leaks(text, rules):
                leaks.append({"path": info.filename, "identifier": leak})
            for category in find_sensitive_findings(text):
                sensitive_findings.append(
                    {"path": info.filename, "category": category}
                )
            if (
                info.filename.lower().startswith("webresources/")
                or suffix in {".html", ".js"}
            ):
                if re.search(
                    r"(?i)https?://[a-z0-9.-]+\.crm(?:\d+)?\.dynamics\.com",
                    text,
                ):
                    web_resource_findings.append(
                        {
                            "path": info.filename,
                            "category": "absolute-dataverse-host",
                        }
                    )

        if missing_members:
            solution_root = None
            manifest = None
            customizations_root = None
        else:
            content_types = _xml_from_zip(archive, "[Content_Types].xml")
            if content_types.tag != f"{{{OPC_NS}}}Types":
                errors.append("[Content_Types].xml has an invalid OPC root")
            solution_root = _xml_from_zip(archive, "solution.xml")
            customizations_root = _xml_from_zip(archive, "customizations.xml")
            if solution_root.tag != "ImportExportXml":
                errors.append("solution.xml root is not ImportExportXml")
            if customizations_root.tag != "ImportExportXml":
                errors.append("customizations.xml root is not ImportExportXml")
            manifest = solution_root.find("SolutionManifest")
            if manifest is None:
                errors.append("solution.xml is missing SolutionManifest")

        inventory = {"total": 0, "counts_by_type": {}, "components": []}
        app_inventory: dict[str, Any] = {}
        dependencies: list[dict[str, Any]] = []
        solution_identity: dict[str, str] = {}
        if manifest is not None:
            solution_identity = {
                "unique_name": manifest.findtext("UniqueName", ""),
                "friendly_name": (
                    manifest.find("LocalizedNames/LocalizedName").get(
                        "description", ""
                    )
                    if manifest.find("LocalizedNames/LocalizedName") is not None
                    else ""
                ),
                "version": manifest.findtext("Version", ""),
                "managed": manifest.findtext("Managed", ""),
            }
            expected_managed = "1" if expected_type == "managed" else "0"
            expected_identity = policy["solution"]
            for key in ("unique_name", "friendly_name", "version"):
                if solution_identity[key] != expected_identity[key]:
                    errors.append(
                        f"unexpected solution {key}: "
                        f"{solution_identity[key]!r}"
                    )
            if solution_identity["managed"] != expected_managed:
                errors.append(
                    f"expected {expected_type} Managed={expected_managed}, "
                    f"got {solution_identity['managed']!r}"
                )
            inventory = _component_inventory(manifest)
            errors.extend(_validate_expected_inventory(inventory, policy))
            if customizations_root is not None:
                app_inventory, app_errors = _validate_expected_app(
                    customizations_root, policy
                )
                errors.extend(app_errors)
            missing = manifest.find("MissingDependencies")
            if missing is not None:
                for item in missing.findall("MissingDependency"):
                    required = item.find("Required")
                    dependent = item.find("Dependent")
                    if required is None or dependent is None:
                        errors.append("malformed MissingDependency entry")
                        continue
                    dependent_data = _dependent_summary(dependent)
                    dependencies.append(
                        {
                            "classification": classify_missing_dependency(
                                dependent_data
                            ),
                            "required": _required_summary(required),
                            "dependent": dependent_data,
                        }
                    )
            if dependencies:
                errors.append(
                    f"solution declares {len(dependencies)} missing dependencies"
                )

        if leaks:
            errors.append(f"found {len(leaks)} prohibited identifier leaks")
        if sensitive_findings:
            errors.append(
                f"found {len(sensitive_findings)} sensitive-content findings"
            )
        if web_resource_findings:
            errors.append(
                f"found {len(web_resource_findings)} absolute Dataverse URLs "
                "in web resources"
            )

    dependency_counts = Counter(
        item["classification"] for item in dependencies
    )
    return {
        "schema_version": "1.0",
        "status": "pass" if not errors else "blocked",
        "zip": {
            "path": str(zip_path),
            "bytes": zip_path.stat().st_size,
            "sha256": sha256_bytes(zip_path.read_bytes()),
            "entry_count": len(entry_manifest),
            "content_manifest_sha256": content_manifest_sha256(
                entry_manifest
            ),
        },
        "solution": solution_identity,
        "component_inventory": inventory,
        "app_inventory": app_inventory,
        "missing_dependencies": {
            "count": len(dependencies),
            "counts_by_classification": dict(sorted(dependency_counts.items())),
            "items": dependencies,
        },
        "identifier_leaks": leaks,
        "sensitive_findings": sensitive_findings,
        "web_resource_findings": web_resource_findings,
        "entry_manifest": entry_manifest,
        "errors": errors,
        "warnings": warnings,
    }


def pack_with_pac(
    source_folder: Path, zip_path: Path, package_type: str
) -> subprocess.CompletedProcess[str]:
    if zip_path.exists():
        raise FileExistsError(
            f"refusing to overwrite existing package: {zip_path}"
        )
    command = [
        "pac",
        "solution",
        "pack",
        "--folder",
        str(source_folder),
        "--zipfile",
        str(zip_path),
        "--packagetype",
        package_type,
    ]
    return subprocess.run(command, check=True, text=True)


def _write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate = subparsers.add_parser("validate")
    validate.add_argument("--zip", type=Path, required=True)
    validate.add_argument(
        "--type", choices=("Managed", "Unmanaged"), required=True
    )
    validate.add_argument("--report", type=Path)
    validate.add_argument(
        "--identifiers", type=Path, default=DEFAULT_IDENTIFIERS
    )
    validate.add_argument("--policy", type=Path, default=DEFAULT_POLICY)

    pack = subparsers.add_parser("pack")
    pack.add_argument("--folder", type=Path, required=True)
    pack.add_argument("--zip", type=Path, required=True)
    pack.add_argument(
        "--type", choices=("Managed", "Unmanaged"), required=True
    )
    pack.add_argument("--report", type=Path)
    pack.add_argument(
        "--identifiers", type=Path, default=DEFAULT_IDENTIFIERS
    )
    pack.add_argument("--policy", type=Path, default=DEFAULT_POLICY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "pack":
        pack_with_pac(args.folder, args.zip, args.type)
    report = validate_solution_zip(
        args.zip,
        args.type,
        identifiers_path=args.identifiers,
        policy_path=args.policy,
    )
    if args.report:
        _write_json(args.report, report)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
