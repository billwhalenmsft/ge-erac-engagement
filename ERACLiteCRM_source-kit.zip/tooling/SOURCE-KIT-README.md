# ERAC Lite CRM source kit

This deterministic source kit supports partner review and governed extension of `GEERACLiteCRM` version `1.0.0.1`. It is not an alternate installation package.

## Contents

- `solution-source/` — exact PAC-unpacked unmanaged solution source;
- `design-source/` — reviewed schema and web-resource authoring sources;
- `scripts/` — sanitized build references (seed/update scripts excluded);
- `tooling/` — fail-closed validator, release policy, and example identifier map;
- `docs/` — business, technical, and partner handoff sources;
- `source-kit-manifest.json` — SHA-256 receipt for every member.

Live environment configuration, deployment maps, credentials, raw data, private identifier maps, internal evidence, and repository metadata are excluded.

## Validation status

The managed and unmanaged PAC exports each contain exactly **zero** `MissingDependency` nodes. The validator also requires the exact ten-table app allowlist, seven curated views, one portable Account form, one sitemap, 13 HTML resources, 17 icons, no optional app settings, and no reviewed private identifiers.

```powershell
python .\tooling\genericize_and_build.py validate `
  --zip .\ERACLiteCRM_managed.zip `
  --type Managed `
  --identifiers .\release-identifiers.private.json `
  --report .\managed-validation.json

```

Create the private identifier map from `tooling/release-identifiers.example.json`; never publish the populated file.

The design schema and imperative scripts are historical references. The unpacked solution source is the component authority. Any provisioning or import changes a Dataverse environment and requires explicit authorization.


