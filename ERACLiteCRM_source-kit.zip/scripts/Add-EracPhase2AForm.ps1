<#
.SYNOPSIS
    Phase 2A form integration:
      - Add erac_activelives + erac_activepolicies fields to the Account form (new section in ERAC 360 tab)
      - Add the External Links web resource as a second section on the ERAC 360 tab
    Idempotent.
#>
param(
    [string]$Org = "https://org-example.crm.dynamics.com",
    [string]$SolutionUniqueName = "GEERACLiteCRM",
    [string]$FormName = "ERAC Cedent 360",
    [string]$TargetTabName = "SUMMARY_TAB",
    [string]$ExternalLinksWR = "erac_/html/external_links_card.html"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$token = (az account get-access-token --resource $Org | ConvertFrom-Json).accessToken
$H = @{
    Authorization      = "Bearer $token"
    "Content-Type"     = "application/json; charset=utf-8"
    Accept             = "application/json"
    "OData-MaxVersion" = "4.0"
    "OData-Version"    = "4.0"
    Prefer             = "return=representation"
}

function Invoke-Dv([string]$Method,[string]$Path,[object]$Body=$null) {
    $p = @{ Uri="$Org/api/data/v9.2/$Path"; Method=$Method; Headers=$H; TimeoutSec=60; UseBasicParsing=$true }
    if ($Body) { $p.Body = ($Body | ConvertTo-Json -Depth 20) }
    try {
        $r = Invoke-WebRequest @p
        if ($r.Content) { return $r.Content | ConvertFrom-Json }
        return @{ ok=$true }
    } catch {
        $msg = try { $_.ErrorDetails.Message } catch { $_.Exception.Message }
        Write-Warning "  x $Method $Path : $($msg.Substring(0,[Math]::Min(400,$msg.Length)))"
        return $null
    }
}

Write-Host "=== PHASE 2A FORM INTEGRATION ===" -ForegroundColor Cyan

# Fetch Account form
$escName = $FormName.Replace("'","''")
$forms = Invoke-Dv GET "systemforms?`$select=formid,name,formxml&`$filter=objecttypecode eq 'account' and type eq 2 and name eq '$escName'"
if (-not $forms -or $forms.value.Count -eq 0) { Write-Error "Form '$FormName' not found." }
$form = $forms.value[0]
[xml]$xml = $form.formxml

# Find the target tab
$eracTab = $xml.SelectNodes("//tab") | Where-Object { $_.name -eq $TargetTabName } | Select-Object -First 1
if (-not $eracTab) { Write-Error "Tab '$TargetTabName' not found on form '$FormName'." }

$sectionsNode = $eracTab.SelectSingleNode("columns/column/sections")
if (-not $sectionsNode) { Write-Error "Tab '$TargetTabName' has no sections node." }

$changed = $false

# ---- SECTION 1: Volume Metrics (Active Lives + Active Policies fields) ----
$volSec = $sectionsNode.SelectNodes("section") | Where-Object { $_.name -eq "erac_volumeSection" } | Select-Object -First 1
if ($volSec) {
    Write-Host "  - Volume Metrics section already exists - skipping" -ForegroundColor Yellow
} else {
    Write-Host "[1] Adding Volume Metrics section with Active Lives / Active Policies..."

    $secGuid = [System.Guid]::NewGuid().ToString("D")
    $sec = $xml.CreateElement("section")
    $sec.SetAttribute("id","{$secGuid}")
    $sec.SetAttribute("name","erac_volumeSection")
    $sec.SetAttribute("showlabel","true")
    $sec.SetAttribute("locklevel","0")
    $sec.SetAttribute("columns","2")

    $lbls = $xml.CreateElement("labels")
    $lbl  = $xml.CreateElement("label")
    $lbl.SetAttribute("description","Volume Metrics")
    $lbl.SetAttribute("languagecode","1033")
    $lbls.AppendChild($lbl) | Out-Null
    $sec.AppendChild($lbls) | Out-Null

    $rows = $xml.CreateElement("rows")
    $row  = $xml.CreateElement("row")

    foreach ($fname in @("erac_activelives","erac_activepolicies")) {
        $cellGuid = [System.Guid]::NewGuid().ToString("D")
        $ctlGuid  = [System.Guid]::NewGuid().ToString("D")
        $cell = $xml.CreateElement("cell")
        $cell.SetAttribute("id","{$cellGuid}")
        $cell.SetAttribute("showlabel","true")
        $cell.SetAttribute("rowspan","1")
        $cell.SetAttribute("colspan","1")
        $cell.SetAttribute("auto","false")

        $cellLbls = $xml.CreateElement("labels")
        $cellLbl  = $xml.CreateElement("label")
        $cellLbl.SetAttribute("description", $(if ($fname -eq "erac_activelives") {"Active Lives"} else {"Active Policies"}))
        $cellLbl.SetAttribute("languagecode","1033")
        $cellLbls.AppendChild($cellLbl) | Out-Null
        $cell.AppendChild($cellLbls) | Out-Null

        $ctl = $xml.CreateElement("control")
        $ctl.SetAttribute("id", $fname)
        $ctl.SetAttribute("classid","{C6D124CA-7EDA-4a60-AEA9-7FB8D318B68F}")  # integer
        $ctl.SetAttribute("datafieldname", $fname)
        $ctl.SetAttribute("disabled","false")
        $cell.AppendChild($ctl) | Out-Null

        $row.AppendChild($cell) | Out-Null
    }

    $rows.AppendChild($row) | Out-Null
    $sec.AppendChild($rows) | Out-Null

    # Insert as the FIRST section (top of ERAC 360 tab)
    $first = $sectionsNode.SelectSingleNode("section[1]")
    if ($first) { $sectionsNode.InsertBefore($sec, $first) | Out-Null }
    else        { $sectionsNode.AppendChild($sec) | Out-Null }

    Write-Host "  + Volume Metrics section added" -ForegroundColor Green
    $changed = $true
}

# ---- SECTION 2: External Links web resource ----
$linksSec = $sectionsNode.SelectNodes("section") | Where-Object { $_.name -eq "erac_externalLinksSection" } | Select-Object -First 1
if ($linksSec) {
    Write-Host "  - External Links section already exists - skipping" -ForegroundColor Yellow
} else {
    Write-Host "[2] Adding External Links section..."

    $secGuid  = [System.Guid]::NewGuid().ToString("D")
    $cellGuid = [System.Guid]::NewGuid().ToString("D")

    $sec = $xml.CreateElement("section")
    $sec.SetAttribute("id","{$secGuid}")
    $sec.SetAttribute("name","erac_externalLinksSection")
    $sec.SetAttribute("showlabel","true")
    $sec.SetAttribute("locklevel","0")
    $sec.SetAttribute("columns","1")

    $lbls = $xml.CreateElement("labels")
    $lbl  = $xml.CreateElement("label")
    $lbl.SetAttribute("description","External Systems")
    $lbl.SetAttribute("languagecode","1033")
    $lbls.AppendChild($lbl) | Out-Null
    $sec.AppendChild($lbls) | Out-Null

    $rows = $xml.CreateElement("rows")
    $row  = $xml.CreateElement("row")
    $cell = $xml.CreateElement("cell")
    $cell.SetAttribute("id","{$cellGuid}")
    $cell.SetAttribute("showlabel","false")
    $cell.SetAttribute("rowspan","3")
    $cell.SetAttribute("colspan","1")
    $cell.SetAttribute("auto","false")

    $cellLbls = $xml.CreateElement("labels")
    $cellLbl  = $xml.CreateElement("label")
    $cellLbl.SetAttribute("description","External Systems")
    $cellLbl.SetAttribute("languagecode","1033")
    $cellLbls.AppendChild($cellLbl) | Out-Null
    $cell.AppendChild($cellLbls) | Out-Null

    $ctl = $xml.CreateElement("control")
    $ctl.SetAttribute("id","WebResource_erac_externalLinks")
    $ctl.SetAttribute("classid","{9FDF5F91-88B1-47f4-AD53-C11EFC01A01D}")
    $ctl.SetAttribute("disabled","false")

    $params = $xml.CreateElement("parameters")
    $urlEl = $xml.CreateElement("Url");            $urlEl.InnerText = $ExternalLinksWR
    $ppEl  = $xml.CreateElement("PassParameters"); $ppEl.InnerText  = "true"
    $scrEl = $xml.CreateElement("Scrolling");      $scrEl.InnerText = "auto"
    $brdEl = $xml.CreateElement("Border");         $brdEl.InnerText = "false"
    $secElP = $xml.CreateElement("Security");      $secElP.InnerText = "false"
    foreach ($e in @($urlEl,$ppEl,$scrEl,$brdEl,$secElP)) { $params.AppendChild($e) | Out-Null }
    $ctl.AppendChild($params) | Out-Null

    $cell.AppendChild($ctl) | Out-Null
    $row.AppendChild($cell) | Out-Null

    # Spacer rows so iframe gets vertical room
    $rows.AppendChild($row) | Out-Null
    for ($i = 0; $i -lt 2; $i++) {
        $spacer = $xml.CreateElement("row")
        $rows.AppendChild($spacer) | Out-Null
    }

    $sec.AppendChild($rows) | Out-Null
    $sectionsNode.AppendChild($sec) | Out-Null

    Write-Host "  + External Links section added" -ForegroundColor Green
    $changed = $true
}

if (-not $changed) {
    Write-Host "`nNo form changes needed." -ForegroundColor Yellow
    exit 0
}

# ---- Save ----
Write-Host "[3] Saving form XML..."
$xwSettings = New-Object System.Xml.XmlWriterSettings
$xwSettings.OmitXmlDeclaration = $true
$xwSettings.Indent = $false
$sb = New-Object System.Text.StringBuilder
$xw = [System.Xml.XmlWriter]::Create($sb, $xwSettings)
$xml.Save($xw); $xw.Flush()
$newXml = $sb.ToString()

$hPatch = $H.Clone(); $hPatch.Remove("Prefer")
try {
    Invoke-WebRequest "$Org/api/data/v9.2/systemforms($($form.formid))" `
        -Method PATCH -Headers $hPatch -Body (@{ formxml=$newXml } | ConvertTo-Json -Depth 3) `
        -UseBasicParsing -TimeoutSec 60 | Out-Null
    Write-Host "  + Form saved" -ForegroundColor Green
} catch {
    $code = try { $_.Exception.Response.StatusCode.value__ } catch { 0 }
    if ($code -le 204 -or $code -eq 0) { Write-Host "  + Form saved" -ForegroundColor Green }
    else { Write-Warning "PATCH failed: $code"; exit 1 }
}

# ---- Publish ----
Write-Host "[4] Publishing account entity..."
Invoke-Dv POST "PublishXml" @{ ParameterXml = "<importexportxml><entities><entity>account</entity></entities></importexportxml>" } | Out-Null
Write-Host "  + Published" -ForegroundColor Green

Write-Host "`nDone. Reload an Account form -> ERAC 360 tab to see Volume Metrics + External Systems." -ForegroundColor Cyan
