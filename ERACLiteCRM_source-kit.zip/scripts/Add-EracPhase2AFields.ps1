<#
.SYNOPSIS
    Phase 2A — Add Active Lives / Active Policies columns to Account.

.DESCRIPTION
    Customer feedback (Slide 6, Cedent 360 enrichments) asked for
    "Active Lives / Active Policies" counts on Cedent 360. These two
    integer columns are added to the Account entity, registered to the
    GEERACLiteCRM solution, and the entity is republished.

    After this runs, Add-EracPhase2AFields-to-Form.ps1 (separate) injects
    them into the ERAC Cedent 360 form, and the Cedent 360 web resource
    surfaces them in the snapshot ribbon.
#>
param(
    [string]$Org = "https://org-example.crm.dynamics.com",
    [string]$SolutionUniqueName = "GEERACLiteCRM",
    [string]$Prefix = "erac"
)
$ErrorActionPreference = "Stop"
$token = (az account get-access-token --resource $Org | ConvertFrom-Json).accessToken
$H = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json; charset=utf-8"
    Accept = "application/json"
    "OData-MaxVersion" = "4.0"
    "OData-Version" = "4.0"
    "MSCRM.SolutionUniqueName" = $SolutionUniqueName
}

function Invoke-Dv {
    param([string]$Method, [string]$Path, [object]$Body = $null)
    $h = $H.Clone()
    if ($Method -in @("POST","PUT","PATCH")) { $h["Prefer"] = "return=representation" }
    $p = @{ Uri = "$Org/api/data/v9.2/$Path"; Method = $Method; Headers = $h; TimeoutSec = 120; UseBasicParsing = $true }
    if ($Body) { $p.Body = ($Body | ConvertTo-Json -Depth 30) }
    try {
        $r = Invoke-WebRequest @p
        if ($r.Content) { return $r.Content | ConvertFrom-Json }
        return @{ ok = $true }
    } catch {
        $msg = try { $_.ErrorDetails.Message } catch { $_.Exception.Message }
        Write-Warning "X $Method $Path : $($msg.Substring(0,[Math]::Min(500,$msg.Length)))"
        return $null
    }
}

function New-Label($txt) {
    @{ LocalizedLabels = @(@{ Label = $txt; LanguageCode = 1033 }); UserLocalizedLabel = @{ Label = $txt; LanguageCode = 1033 } }
}

Write-Host "=== PHASE 2A — Active Lives / Policies on Account ===" -ForegroundColor Cyan

$existing = (Invoke-Dv GET 'EntityDefinitions(LogicalName=''account'')/Attributes?$select=LogicalName').value
$existingNames = @{}; $existing | ForEach-Object { $existingNames[$_.LogicalName] = $true }

function Add-Attr($logical, $body) {
    if ($existingNames.ContainsKey($logical)) {
        Write-Host "  - $logical exists, skipping" -ForegroundColor DarkGray
        return
    }
    $r = Invoke-Dv POST "EntityDefinitions(LogicalName='account')/Attributes" $body
    if ($r) { Write-Host "  + Created $logical" -ForegroundColor Green }
}

Add-Attr "${Prefix}_activelives" @{
    "@odata.type" = "Microsoft.Dynamics.CRM.IntegerAttributeMetadata"
    AttributeType = "Integer"; AttributeTypeName = @{ Value = "IntegerType" }
    SchemaName = "${Prefix}_ActiveLives"
    DisplayName = (New-Label "Active Lives")
    Description = (New-Label "Count of active insured lives covered under this cedent (sum across all in-force treaties).")
    RequiredLevel = @{ Value = "None" }
    MinValue = 0; MaxValue = 2147483647; Format = "None"
}

Add-Attr "${Prefix}_activepolicies" @{
    "@odata.type" = "Microsoft.Dynamics.CRM.IntegerAttributeMetadata"
    AttributeType = "Integer"; AttributeTypeName = @{ Value = "IntegerType" }
    SchemaName = "${Prefix}_ActivePolicies"
    DisplayName = (New-Label "Active Policies")
    Description = (New-Label "Count of active policies under this cedent (sum across all in-force treaties).")
    RequiredLevel = @{ Value = "None" }
    MinValue = 0; MaxValue = 2147483647; Format = "None"
}

# Publish account
Invoke-Dv POST "PublishXml" @{ ParameterXml = "<importexportxml><entities><entity>account</entity></entities></importexportxml>" } | Out-Null
Write-Host "`nDone." -ForegroundColor Green
