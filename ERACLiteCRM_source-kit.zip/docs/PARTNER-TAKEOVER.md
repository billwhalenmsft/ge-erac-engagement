# GE ERAC Lite CRM — partner takeover

**Audience:** implementation partner / solution owner
**Release state:** validated source and artifact handoff; publication approval pending

## What you receive

- untouched PAC managed and unmanaged exports of `GEERACLiteCRM` `1.0.0.1`;
- exact hashes, entry manifests, component inventory, and zero-dependency evidence;
- a deterministic sanitized source kit and fail-closed validation harness;
- reviewed schema, build references, web-resource source, and handoff guidance;
- a local customer-safe site preview and private managed-update receipt.

The ZIPs contain no data. Seed/provisioning material is excluded from the external package.

## Completed source remediation

- Replaced the polluted Account form with `ERAC Cedent 360 Portable`, containing only reviewed standard controls, 22 solution-owned `erac_` fields, and four relative ERAC web resources.
- Preserved the prior `ERAC 360` environment form while removing it from the source solution and app selection.
- Rebuilt the app and sitemap to exactly ten tables, seven curated views, one portable form, 13 ERAC HTML resources, and 17 ERAC icons.
- Removed Lead, Opportunity, Inbox/Sales/Service-derived assets, unrelated entities, and the two optional app settings from the exported app.
- Bumped the solution to `1.0.0.1`, performed only targeted publish, and re-exported with PAC.
- Achieved exactly zero `MissingDependency` nodes in both exports.

No dependency XML was deleted and no GUID placeholder was used.

## Validate

```powershell
python .\tooling\genericize_and_build.py validate `
  --zip .\ERACLiteCRM_managed.zip `
  --type Managed `
  --identifiers .\release-identifiers.private.json `
  --report .\managed-validation.json

```

Create the populated private identifier map locally from the example; never publish it.

## Deployment boundary

Use the managed package for governed target deployment and the unmanaged package only in partner development. The exact managed artifact passed a normal update in a pre-provisioned environment; this is not a clean-first-install proof. Do not use uninstall, upgrade, force-overwrite, or dependency bypass without a separately approved plan.

The partner owns target prerequisites, security, migration, integrations, licensing, monitoring, ALM, and support. Demo-data provenance remains withheld.
