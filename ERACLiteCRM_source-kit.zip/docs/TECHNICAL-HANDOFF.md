# GE ERAC Lite CRM — technical handoff

**Audience:** Power Platform administrators and implementation engineers
**Release state:** validated local candidate; publication and customer deployment approval pending

## Exact artifacts

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `ERACLiteCRM_managed.zip` | 141,342 | `50984d76b2fcd41c5f58d22d42211a5e02a38f1828975cd9e4a74db794cb2afc` |
| `ERACLiteCRM_unmanaged.zip` | 141,561 | `349216b2b62fd218e406e0a9356e89d00602bd2b898e7f2fa1dbe2d52a8e2511` |

Both are untouched PAC exports of `GEERACLiteCRM` version `1.0.0.1` with the expected managed flag.

## Structural result

Both exports pass the fail-closed validator with exactly **zero** `MissingDependency` nodes, zero reviewed identifier leaks, zero sensitive-content findings, and zero absolute Dataverse URLs in web resources.

| Root component type | Count | Detail |
|---|---:|---|
| Tables | 10 | Account, Appointment, System User, Task, and six `erac_*` tables |
| Web resources | 30 | 13 HTML resources and 17 icons |
| App module sitemap | 1 | `erac_ERACLiteCRM` |
| Model-driven app | 1 | `erac_ERACLiteCRM` |

The app allowlist contains exactly those ten tables, seven curated views, the `ERAC Cedent 360 Portable` Account form, and one sitemap. The portable form contains 31 allowlisted fields and four relative ERAC web resources. `AppChannel` and `m365copilotmodelappenabled` are absent from the exported app.

The export has no root flows, connection references, environment variables, plug-ins, custom connectors, or security roles.

## Managed-update evidence

The exact managed SHA above was imported as a normal, non-destructive update over managed `1.0.0.0` in the pre-provisioned Primary CE environment. PAC exited `0`; the asynchronous import completed as **Succeeded** with no import error. The solution verified as managed `1.0.0.1`, and the app validated successfully with the intended navigation, form, views, resources, and open path.

Record-ID receipts were identical before and after for all ten app tables: 43 Accounts, 30 Appointments, 265 System Users, 8 Tasks, and zero records across the six ERAC custom tables. No uninstall, delete, force-overwrite, stage-and-upgrade, provisioning, or record write was used.

This proves a **managed update in a pre-provisioned environment**, not a clean first install. Normal update semantics retained the prior managed `ERAC 360` component and two prior managed app-setting instances in that target solution layer. They are not selected by the updated app, and they are not present in the `1.0.0.1` export. Static zero-dependency validation is the separate portability evidence.

## Controlled import path

After target readiness and approval:

```powershell
pac solution import --environment https://TARGET.crm.dynamics.com `
  --path .\ERACLiteCRM_managed.zip `
  --async true `
  --max-async-wait-time 60
```

Do not use uninstall, stage-and-upgrade, force-overwrite, or dependency bypass without a separately approved change plan. Verify the exact SHA-256 before import and preserve a before/after record-ID receipt.

## Boundaries

The ZIP installs no customer/demo records. Demo-data provenance remains withheld. Target security roles, licensing, integrations, migration, ALM, monitoring, and production support remain customer/partner responsibilities. A clean-first-install test has not been claimed.
