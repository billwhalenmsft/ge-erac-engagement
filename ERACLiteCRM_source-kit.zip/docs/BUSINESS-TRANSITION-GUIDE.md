# GE ERAC Lite CRM — business transition guide

**Audience:** ERAC business owners and program leadership
**Release state:** validated local candidate; publication approval pending

## What the solution provides

ERAC Lite CRM is a Dataverse model-driven application for cedent relationship and engagement work. Version `1.0.0.1` includes:

- one ERAC Lite CRM app and curated sitemap;
- Account, Appointment, System User, and Task customizations;
- six ERAC custom tables: Account Team, Dispute, Partnership Rating, Reserve Adequacy, Risk Assessment, and Treaty;
- a portable Account form with ERAC fields and relative ERAC resources;
- 13 HTML resources and 17 icons;
- curated ERAC views, forms, charts, relationships, and calculated behavior.

## Evidence status

The managed and unmanaged exports each contain exactly zero declared missing dependencies and pass reviewed leak, structure, inventory, form, sitemap, and app checks. The exact managed artifact also completed a non-destructive update from `1.0.0.0` to `1.0.0.1` in a pre-provisioned Primary CE environment. Existing record IDs and counts were unchanged.

That test is an update proof, not a clean-first-install claim. The static zero-dependency export is the separate portability evidence.

## What is not included

The solution ZIP installs no customer or demo records. No demo-data archive is included because external-use provenance has not been independently established.

The package contains no Power Automate flows, connection references, environment variables, plug-ins, custom connectors, or security roles. Copilot Studio, production Power BI, contract integration, legacy migration, production routing, and deeper actuarial/legal capabilities remain separate work.

## Ownership boundary

ERAC or its implementation partner owns target readiness, licensing, security roles, data migration, integrations, support, and production operations. Microsoft has prepared and validated this local candidate but has not approved publication or customer deployment.
